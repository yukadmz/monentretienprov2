<?php
// Vérifie si l'utilisateur est connecté, sinon redirige vers la page d'authentification
session_start();
if (!isset($_SESSION['loggedin']) || $_SESSION['loggedin'] !== true) {
    header('Location: index.php');
    exit;
}

// Reste du code de votre page...
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Tableau de bord - Suivi des Candidatures</title>
    <link rel="stylesheet" href="assets/css/style.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
    <link rel="manifest" href="manifest.json">
    <link rel="icon" type="image/png" href="assets/img/favicon.png">
    <script>
  if ('serviceWorker' in navigator) {
    window.addEventListener('load', function() {
      navigator.serviceWorker.register('https://axeld.yn.lu/monentretienpro/service-worker.js').then(function(registration) {
        console.log('ServiceWorker registration successful with scope: ', registration.scope);
      }, function(err) {
        console.log('ServiceWorker registration failed: ', err);
      });
    });
  }
</script>
</head>
<body>
<?php include 'assets/include/navbar.php'; ?>
    <div class="container">
        <h1>Tableau de bord</h1>
        <?php $candidatures = json_decode(file_get_contents('assets/data/candidatures.json'), true); ?>
        <?php if ($_COOKIE['role'] === 'administrateur' || $_COOKIE['role'] === 'modification') : ?>
        <?php
                
                // Vérification s'il y a un enregistrement de date limite de recherche
                $candidaturesEnCours = array_filter($candidatures, function($candidature) {
                    return $candidature['statut'] === 'Config';
                });

                if (empty($candidaturesEnCours)) {
                    echo "<p style='text-align:center;'>Aucune date limite de recherche d'emploi n'a été déterminée.</p>";
                } else {
                        echo "<p style='text-align:center; color:red; text-decoration:bold; font-size:25px;';><strong>";
                    foreach ($candidaturesEnCours as $candidature) {
                        echo "<a href='modif_candidature.php?id={$candidature['id']}'>{$candidature['entreprise']} {$candidature['poste']}</a>";
                        echo "</strong></p>";
                    }
                }
                ?>
            <?php endif; ?>
        <?php if ($_COOKIE['role'] === 'lecture') : ?>
        <?php
                
                // Vérification s'il y a un enregistrement de date limite de recherche
                $candidaturesEnCours = array_filter($candidatures, function($candidature) {
                    return $candidature['statut'] === 'Config';
                });

                if (empty($candidaturesEnCours)) {
                    echo "<p style='text-align:center;'>Aucune date limite de recherche d'emploi n'a été déterminée.</p>";
                } else {
                        echo "<p style='text-align:center; color:red; text-decoration:bold; font-size:25px;';><strong>";
                    foreach ($candidaturesEnCours as $candidature) {
                        echo "{$candidature['entreprise']} {$candidature['poste']}";
                        echo "</strong></p>";
                    }
                }
                ?>
            <?php endif; ?>
        <div class="dashboard">
            <div class="card">
    <h2><i class="fas fa-hourglass-start"></i> Candidatures en attente</h2>
    <?php // Lecture du contenu du fichier JSON
    $candidatures = json_decode(file_get_contents('assets/data/candidatures.json'), true);
    ?>
    <?php if ($_COOKIE['role'] === 'administrateur' || $_COOKIE['role'] === 'modification') : ?>
        <?php
        // Vérification s'il y a des candidatures en cours
        $candidaturesEnAttente = array_filter($candidatures, function($candidature) {
            return $candidature['statut'] === 'En attente';
        });

        if (!empty($candidaturesEnAttente)) :
            foreach ($candidaturesEnAttente as $candidature) :
        ?>
                <div class="card-dashboard">
                    <a href='modif_candidature.php?id=<?php echo $candidature['id']; ?>'>
                        <h3><?php echo $candidature['entreprise'] . ' - ' . $candidature['poste']; ?></h3>
                    </a>
                </div>
        <?php
            endforeach;
        else :
            echo "<p>Aucune candidature en attente.</p>";
        endif;
        ?>
    <?php endif; ?>
    <?php if ($_COOKIE['role'] === 'lecture') : ?>
        <?php
        // Vérification s'il y a des candidatures en cours
        $candidaturesEnAttente = array_filter($candidatures, function($candidature) {
            return $candidature['statut'] === 'En attente';
        });

        if (!empty($candidaturesEnAttente)) :
            foreach ($candidaturesEnAttente as $candidature) :
        ?>
                <div class="card-dashboard">
                    <a href='lecture_candidature.php?id=<?php echo $candidature['id']; ?>'>
                        <h3><?php echo $candidature['entreprise'] . ' - ' . $candidature['poste']; ?></h3>
                    </a>
                </div>
        <?php
            endforeach;
        else :
            echo "<p>Aucune candidature en attente.</p>";
        endif;
        ?>
    <?php endif; ?>
</div>

           <div class="card">
    <h2><i class="fas fa-hourglass-half"></i> Candidatures en cours</h2>
    <?php // Lecture du contenu du fichier JSON
    $candidatures = json_decode(file_get_contents('assets/data/candidatures.json'), true);
    ?>
    <?php if ($_COOKIE['role'] === 'administrateur' || $_COOKIE['role'] === 'modification') : ?>
        <?php
        // Vérification s'il y a des candidatures en cours
        $candidaturesEnCours = array_filter($candidatures, function($candidature) {
            return $candidature['statut'] === 'En cours';
        });

        if (!empty($candidaturesEnCours)) :
            foreach ($candidaturesEnCours as $candidature) :
        ?>
                <div class="card-dashboard">
                    <a href='modif_candidature.php?id=<?php echo $candidature['id']; ?>'>
                        <h3><?php echo $candidature['entreprise'] . ' - ' . $candidature['poste']; ?></h3>
                    </a>
                </div>
        <?php
            endforeach;
        else :
            echo "<p>Aucune candidature en cours.</p>";
        endif;
        ?>
    <?php endif; ?>
    <?php if ($_COOKIE['role'] === 'lecture') : ?>
        <?php
        // Vérification s'il y a des candidatures en cours
        $candidaturesEnCours = array_filter($candidatures, function($candidature) {
            return $candidature['statut'] === 'En cours';
        });

        if (!empty($candidaturesEnCours)) :
            foreach ($candidaturesEnCours as $candidature) :
        ?>
                <div class="card-dashboard">
                    <a href='lecture_candidature.php?id=<?php echo $candidature['id']; ?>'>
                        <h3><?php echo $candidature['entreprise'] . ' - ' . $candidature['poste']; ?></h3>
                    </a>
                </div>
        <?php
            endforeach;
        else :
            echo "<p>Aucune candidature en cours.</p>";
        endif;
        ?>
    <?php endif; ?>
</div>

<div class="card">
    <h2><i class="fas fa-calendar"></i> Entretiens en attente</h2>
    <?php // Lecture du contenu du fichier JSON
    $candidatures = json_decode(file_get_contents('assets/data/candidatures.json'), true);
    ?>
    <?php if ($_COOKIE['role'] === 'administrateur' || $_COOKIE['role'] === 'modification') : ?>
        <?php
        // Vérification s'il y a des entretiens en attente
        $entretiensEnAttente = array_filter($candidatures, function($candidature) {
            return $candidature['statut'] === 'Entretien';
        });

        if (!empty($entretiensEnAttente)) :
            foreach ($entretiensEnAttente as $entretien) :
        ?>
                <div class="card-dashboard">
                    <a href='modif_candidature.php?id=<?php echo $entretien['id']; ?>'>
                        <h3><?php echo $entretien['entreprise'] . ' - ' . $entretien['poste'] . ' - ' . date("d/m/Y", strtotime($entretien['date_entretien'])); ?></h3>
                    </a>
                </div>
        <?php
            endforeach;
        else :
            echo "<p>Aucun entretien programmé.</p>";
        endif;
        ?>
    <?php endif; ?>
    <?php if ($_COOKIE['role'] === 'lecture') : ?>
        <?php
        // Vérification s'il y a des entretiens en attente
        $entretiensEnAttente = array_filter($candidatures, function($candidature) {
            return $candidature['statut'] === 'Entretien';
        });

        if (!empty($entretiensEnAttente)) :
            foreach ($entretiensEnAttente as $entretien) :
        ?>
                <div class="card-dashboard">
                    <a href='lecture_candidature.php?id=<?php echo $entretien['id']; ?>'>
                        <h3><?php echo $entretien['entreprise'] . ' - ' . $entretien['poste'] . ' - ' . date("d/m/Y", strtotime($entretien['date_entretien'])); ?></h3>
                    </a>
                </div>
        <?php
            endforeach;
        else :
            echo "<p>Aucun entretien programmé.</p>";
        endif;
        ?>
    <?php endif; ?>
</div>

<div class="card">
    <h2><i class="fas fa-calendar-check"></i> Entretiens passés</h2>
    <?php // Lecture du contenu du fichier JSON
    $candidatures = json_decode(file_get_contents('assets/data/candidatures.json'), true);
    ?>
    <?php if ($_COOKIE['role'] === 'administrateur' || $_COOKIE['role'] === 'modification') : ?>
        <?php
        // Vérification s'il y a des entretiens passés
        $entretiensPasses = array_filter($candidatures, function($candidature) {
            return $candidature['statut'] === 'Entretien passé';
        });

        if (!empty($entretiensPasses)) :
            foreach ($entretiensPasses as $entretien) :
        ?>
                <div class="card-dashboard">
                    <a href='modif_candidature.php?id=<?php echo $entretien['id']; ?>'>
                        <h3><?php echo $entretien['entreprise'] . ' - ' . $entretien['poste'] . ' - ' . date("d/m/Y", strtotime($entretien['date_entretien'])); ?></h3>
                    </a>
                </div>
        <?php
            endforeach;
        else :
            echo "<p>Aucun entretien passé.</p>";
        endif;
        ?>
    <?php endif; ?>
    <?php if ($_COOKIE['role'] === 'lecture') : ?>
        <?php
        // Vérification s'il y a des entretiens passés
        $entretiensPasses = array_filter($candidatures, function($candidature) {
            return $candidature['statut'] === 'Entretien passé';
        });

        if (!empty($entretiensPasses)) :
            foreach ($entretiensPasses as $entretien) :
        ?>
                <div class="card-dashboard">
                    <a href='lecture_candidature.php?id=<?php echo $entretien['id']; ?>'>
                        <h3><?php echo $entretien['entreprise'] . ' - ' . $entretien['poste'] . ' - ' . date("d/m/Y", strtotime($entretien['date_entretien'])); ?></h3>
                    </a>
                </div>
        <?php
            endforeach;
        else :
            echo "<p>Aucun entretien passé.</p>";
        endif;
    ?>
    <?php endif; ?>
</div>

            <div class="card">
    <h2><i class="fas fa-check-circle"></i> Candidatures acceptées</h2>
    <?php // Lecture du contenu du fichier JSON
    $candidatures = json_decode(file_get_contents('assets/data/candidatures.json'), true);
    ?>
    <?php if ($_COOKIE['role'] === 'administrateur' || $_COOKIE['role'] === 'modification') : ?>
        <?php
        // Vérification s'il y a des candidatures acceptées
        $candidaturesAcceptees = array_filter($candidatures, function($candidature) {
            return $candidature['statut'] === 'Acceptée';
        });

        if (!empty($candidaturesAcceptees)) :
            foreach ($candidaturesAcceptees as $candidature) :
        ?>
                <div class="card-dashboard">
                    <a href='modif_candidature.php?id=<?php echo $candidature['id']; ?>'>
                        <h3><?php echo $candidature['entreprise'] . ' - ' . $candidature['poste']; ?></h3>
                    </a>
                </div>
        <?php
            endforeach;
        else :
            echo "<p>Aucune proposition d'embauche.</p>";
        endif;
        ?>
    <?php endif; ?>
    <?php if ($_COOKIE['role'] === 'lecture') : ?>
        <?php
        // Vérification s'il y a des candidatures acceptées
        $candidaturesAcceptees = array_filter($candidatures, function($candidature) {
            return $candidature['statut'] === 'Acceptée';
        });

        if (!empty($candidaturesAcceptees)) :
            foreach ($candidaturesAcceptees as $candidature) :
        ?>
                <div class="card-dashboard">
                    <a href='lecture_candidature.php?id=<?php echo $candidature['id']; ?>'>
                        <h3><?php echo $candidature['entreprise'] . ' - ' . $candidature['poste']; ?></h3>
                    </a>
                </div>
        <?php
            endforeach;
        else :
            echo "<p>Aucune proposition d'embauche.</p>";
        endif;
    ?>
    <?php endif; ?>
</div>

            <div class="card">
    <h2><i class="fas fa-times-circle"></i> Candidatures refusées</h2>
    <?php // Lecture du contenu du fichier JSON
    $candidatures = json_decode(file_get_contents('assets/data/candidatures.json'), true);
    ?>
    <?php if ($_COOKIE['role'] === 'administrateur' || $_COOKIE['role'] === 'modification') : ?>
        <?php
        // Vérification s'il y a des candidatures refusées
        $candidaturesRefusees = array_filter($candidatures, function($candidature) {
            return $candidature['statut'] === 'Refusée';
        });

        if (!empty($candidaturesRefusees)) :
            foreach ($candidaturesRefusees as $candidature) :
        ?>
                <div class="card-dashboard">
                    <a href='modif_candidature.php?id=<?php echo $candidature['id']; ?>'>
                        <h3><?php echo $candidature['entreprise'] . ' - ' . $candidature['poste']; ?></h3>
                    </a>
                </div>
        <?php
            endforeach;
        else :
            echo "<p>Aucune candidature refusée.</p>";
        endif;
        ?>
    <?php endif; ?>
    <?php if ($_COOKIE['role'] === 'lecture') : ?>
        <?php
        // Vérification s'il y a des candidatures refusées
        $candidaturesRefusees = array_filter($candidatures, function($candidature) {
            return $candidature['statut'] === 'Refusée';
        });

        if (!empty($candidaturesRefusees)) :
            foreach ($candidaturesRefusees as $candidature) :
        ?>
                <div class="card-dashboard">
                    <a href='lecture_candidature.php?id=<?php echo $candidature['id']; ?>'>
                        <h3><?php echo $candidature['entreprise'] . ' - ' . $candidature['poste']; ?></h3>
                    </a>
                </div>
        <?php
            endforeach;
        else :
            echo "<p>Aucune candidature refusée.</p>";
        endif;
    ?>
    <?php endif; ?>
</div>

        </div>
        
            

        <!-- Bouton pour exporter vers un fichier PDF -->
        <form action="export_pdf_all.php" method="post">
            <input type="submit" value="Tout exporter en PDF" class="btn">
        </form>
    </div>
</body>
</html>